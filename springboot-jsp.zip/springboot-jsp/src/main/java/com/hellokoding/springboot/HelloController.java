package com.hellokoding.springboot;





import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@Controller
public class HelloController {
    @RequestMapping("/hello")
    public String getCartList(Map<String, Object> model) {

        JSONObject responseDetailsJson = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        model.put("message", "HowToDoInJava Reader !!");
        List<String> cartList = new Vector<String>(5);
        HashMap<String,String> map=new HashMap<>();
            map.put("Arun","B");
            map.put("Abhi","C");
            map.put("Arjun","D");
            map.put("Ak","K");
            map.put("Ah","K");
        for(String p:map.keySet()) {
            cartList.add(p);
            JSONObject formDetailsJson = new JSONObject();
            formDetailsJson.put("name", p);
            jsonArray.put(formDetailsJson);;
            model.put("message", jsonArray);
        }
        responseDetailsJson.put("forms", jsonArray);//Here you can see the data in json format

        return "hello";

    }
   /* @RequestMapping("/")
    public String test(){
        return "hello";
    }*/
}
